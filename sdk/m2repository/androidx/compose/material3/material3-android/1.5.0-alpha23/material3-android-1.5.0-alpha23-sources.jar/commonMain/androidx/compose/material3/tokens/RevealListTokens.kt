/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// VERSION: 29.0.0
// GENERATED CODE - DO NOT MODIFY BY HAND

package androidx.compose.material3.tokens

internal object RevealListTokens {
    val ItemActionButtonIconIconColor = ColorSchemeKeyTokens.OnPrimary
    val ItemActionIconButtonContainerColor = ColorSchemeKeyTokens.Primary
    val ItemButtonIconIconColor = ColorSchemeKeyTokens.OnSecondaryContainer
    val ItemContainerColor = ColorSchemeKeyTokens.Surface
    val ItemContainerShape = ShapeKeyTokens.CornerLarge
    val ItemIconButtonActionContainerShape = ShapeKeyTokens.CornerLarge
    val ItemIconButtonContainerColor = ColorSchemeKeyTokens.SecondaryContainer
    val ItemIconButtonContainerShape = ShapeKeyTokens.CornerFull
    val ItemSegmentedContainerShape = ShapeKeyTokens.CornerLarge
}
